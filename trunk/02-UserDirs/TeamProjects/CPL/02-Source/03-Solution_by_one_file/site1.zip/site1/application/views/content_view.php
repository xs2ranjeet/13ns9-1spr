<div class="art-content-layout">
<div class="art-content-layout-row">
<div class="art-layout-cell art-content">
    <div class="art-post">
        <div class="art-post-body">
    <div class="art-post-inner art-article">

    <!-- block-content -->
        <?php echo $err;?>
        тут потрібно вивести каталог продукції
        тут потрібно вивести каталог продукції
        тут потрібно вивести каталог продукції
        тут потрібно вивести каталог продукції
    <!-- /block-content -->
    </div>
     </div>
    <div class="cleared"></div>

    </div>
</div>


<div class="art-layout-cell art-sidebar1">

<div class="art-block">
<div class="art-block-tl"></div>
<div class="art-block-tr"></div>
<div class="art-block-bl"></div>
<div class="art-block-br"></div>
<div class="art-block-tc"></div>
<div class="art-block-bc"></div>
<div class="art-block-cl"></div>
<div class="art-block-cr"></div>
<div class="art-block-cc"></div>
<div class="art-block-body">
    <div class="art-blockheader">
        <div class="l"></div>
        <div class="r"></div>
         <div class="t">Contact Info</div>
    </div>
    <div class="art-blockcontent">
        <div class="art-blockcontent-body">
    <!-- block-content -->
        <div>
          <img src="<?php echo base_url().'images/contact.jpg';?>" alt="an image" style="margin: 0 auto;display:block;width:95%" />
        <br />
        <b>Company Co.</b><br />
        Las Vegas, NV 12345<br />
        Email: <a href="mailto:info@company.com">info@company.com</a><br />
        <br />
        Phone: (123) 456-7890 <br />
        Fax: (123) 456-7890
        </div>
    <!-- /block-content -->

        <div class="cleared"></div>
        </div>
    </div>
<div class="cleared"></div>
</div>
</div>
</div>


</div>
</div>