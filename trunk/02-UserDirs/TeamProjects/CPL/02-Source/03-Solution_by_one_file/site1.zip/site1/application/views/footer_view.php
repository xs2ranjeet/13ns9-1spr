<div class="art-footer">
<div class="art-footer-t"></div>
<div class="art-footer-l"></div>
<div class="art-footer-b"></div>
<div class="art-footer-r"></div>
<div class="art-footer-body">
     <a href="#" class="art-rss-tag-icon" title="RSS"></a>
    <div class="art-footer-text">
        <p><a href="#">Contact Us</a> | <a href="#">Terms of Use</a> | <a href="#">Trademarks</a>
            | <a href="#">Privacy Statement</a><br />
            Copyright &copy; 2010 ---. All Rights Reserved.</p>
    </div>
    <div class="cleared"></div>
</div>
</div>
