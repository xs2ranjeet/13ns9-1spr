<div class="art-nav">
    <div class="l"></div>
    <div class="r"></div>
    <ul class="art-menu">
            <li>
                <a href="<?php echo base_url().'index.php/'.$home;?>" class="active">
                    <span class="l"></span>
                    <span class="r"></span>
                    <span class="t">Домашня</span>
                </a>
            </li>
            <li>
                 <a href="<?php echo base_url().'index.php/'.$catalog;?>">
                     <span class="l"></span>
                     <span class="r"></span>
                     <span class="t">Каталог продукції</span>
                 </a>
            </li>
            <li>
                <a href="<?php echo base_url().'index.php/'.$about;?>">
                    <span class="l"></span>
                    <span class="r"></span>
                    <span class="t">Про компанію</span>
                </a>
            </li>
    </ul>
</div>