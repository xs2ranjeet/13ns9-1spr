<div class="art-header">
    <div class="art-header-png"></div>
    <div class="art-header-jpeg"></div>
    <div class="art-logo">
        <h1 id="name-text" class="art-logo-name"><a href="#"></a></h1>
        <div id="slogan-text" class="art-logo-text"> </div>
    </div>
</div>